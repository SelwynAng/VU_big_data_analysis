import multiprocessing


def worker():
    print('Worker started...')
    for i in range(1, 10000000):
        pass
    print('Worker finished...')


'''
Note that we enclosed the code to create and start the process inside the 
if __name__ == '__main__': block. 
This is necessary to prevent the newly created process from trying to start its own subprocesses, 
which can lead to unexpected behavior.
'''
if __name__ == '__main__':
    p = multiprocessing.Process(target=worker)
    p.start()
    print("Main process continues to run...")

    p.join()
    print("Main process waits for the worker process to finish...")


