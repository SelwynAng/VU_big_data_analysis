import multiprocessing as mp
print("Number of processors: ", mp.cpu_count())
